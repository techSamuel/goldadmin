

<?php $__env->startSection('content'); ?>
    <div class="max-w-6xl mx-auto">
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Push Notifications</h1>
                <p class="text-gray-600 mt-2">Manage and send push notifications to app users.</p>
            </div>
            <a href="<?php echo e(route('admin.notifications.create')); ?>"
                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg shadow transition">
                + Send New Notification
            </a>
        </div>

        <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-50 text-slate-700 text-sm uppercase tracking-wider border-b border-gray-200">
                        <th class="p-6 font-semibold">Image</th>
                        <th class="p-6 font-semibold">Title</th>
                        <th class="p-6 font-semibold">Body</th>
                        <th class="p-6 font-semibold">Type</th>
                        <th class="p-6 font-semibold">Sent At</th>
                        <th class="p-6 font-semibold">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="p-6">
                                <?php if($notification->image_url): ?>
                                    <a href="<?php echo e($notification->image_url); ?>" target="_blank">
                                        <img src="<?php echo e($notification->image_url); ?>" alt="Img"
                                            class="w-10 h-10 rounded object-cover border">
                                    </a>
                                <?php else: ?>
                                    <span class="text-gray-300">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-6 font-medium text-gray-800"><?php echo e($notification->title); ?></td>
                            <td class="p-6 text-gray-600 max-w-xs truncate"><?php echo e($notification->body); ?></td>
                            <td class="p-6">
                                <span class="px-3 py-1 text-xs font-bold rounded-full 
                                                            <?php if($notification->type == 'promo'): ?> bg-green-100 text-green-700
                                                            <?php elseif($notification->type == 'alert'): ?> bg-red-100 text-red-700
                                                            <?php else: ?> bg-blue-100 text-blue-700 <?php endif; ?>">
                                    <?php echo e(ucfirst($notification->type)); ?>

                                </span>
                            </td>
                            <td class="p-6 text-gray-500 text-sm"><?php echo e($notification->sent_at->format('M d, Y h:i A')); ?></td>
                            <td class="p-6">
                                <?php if(isset($notification->response['success']) && $notification->response['success']): ?>
                                    <span class="text-green-600 font-bold text-xs">Sent</span>
                                <?php else: ?>
                                    <span class="text-red-500 font-bold text-xs">Failed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="p-12 text-center text-gray-500">
                                No notifications found. Start by sending one!
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-6">
            <?php echo e($notifications->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\WorkSpace\Antigravity\GoldCalculator\backend\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>