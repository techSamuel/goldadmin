

<?php $__env->startSection('content'); ?>
    <div class="bg-white rounded shadow p-6">
        <h2 class="text-2xl font-bold mb-4">AdMob Configuration (Android)</h2>

        <form action="<?php echo e(route('admin.admob.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label class="flex items-center space-x-2">
                    <input type="checkbox" name="is_enabled" value="1" <?php echo e($config->is_enabled ? 'checked' : ''); ?>

                        class="form-checkbox h-5 w-5 text-yellow-600">
                    <span class="text-gray-700 font-medium">Enable Ads in App</span>
                </label>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">Banner Ad ID</label>
                <input type="text" name="banner_id" value="<?php echo e($config->banner_id); ?>"
                    class="w-full border rounded px-3 py-2 focus:outline-none focus:ring focus:border-yellow-500"
                    placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">Interstitial Ad ID</label>
                <input type="text" name="interstitial_id" value="<?php echo e($config->interstitial_id); ?>"
                    class="w-full border rounded px-3 py-2 focus:outline-none focus:ring focus:border-yellow-500"
                    placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">Rewarded Ad ID</label>
                <input type="text" name="rewarded_id" value="<?php echo e($config->rewarded_id); ?>"
                    class="w-full border rounded px-3 py-2 focus:outline-none focus:ring focus:border-yellow-500"
                    placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/xxxxxxxxxx">
            </div>

            <button type="submit" class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded">
                Save Configuration
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\WorkSpace\Antigravity\GoldCalculator\backend\resources\views/admin/admob/index.blade.php ENDPATH**/ ?>