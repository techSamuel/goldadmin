<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gold Calculator Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>

<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <?php if(auth()->guard('admin')->check()): ?>
            <div class="w-64 bg-slate-900 text-white flex-shrink-0">
                <div class="p-6">
                    <div class="flex items-center gap-2">
                        <?php if(isset($branding['admin_logo']) && $branding['admin_logo']): ?>
                            <img src="<?php echo e($branding['admin_logo']); ?>" alt="Logo" class="h-8 w-auto">
                        <?php endif; ?>
                        <h1 class="text-xl font-bold text-yellow-500"><?php echo e($branding['admin_panel_name'] ?? 'Gold Admin'); ?>

                        </h1>
                    </div>
                </div>
                <nav class="mt-4">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Dashboard</a>
                    <a href="<?php echo e(route('admin.prices.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.prices.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Manage
                        Prices</a>
                    <a href="<?php echo e(route('admin.announcements.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.announcements.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Announcements</a>
                    <a href="<?php echo e(route('admin.notifications.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.notifications.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Notifications</a>
                    <a href="<?php echo e(route('admin.settings.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.settings.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Settings</a>
                    <a href="<?php echo e(route('admin.feedback.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.feedback.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Feedback</a>
                    <a href="<?php echo e(route('admin.users.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.users.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">App
                        Users</a>


                    <a href="<?php echo e(route('admin.admins.index')); ?>"
                        class="block py-3 px-6 hover:bg-slate-800 <?php echo e(request()->routeIs('admin.admins.*') ? 'bg-slate-800 border-l-4 border-yellow-500' : ''); ?>">Manage
                        Admins</a>

                </nav>
                <div class="absolute bottom-0 w-64 p-4">
                    <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                            class="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded">Logout</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- Content -->
        <div class="flex-1 flex flex-col">
            <main class="flex-1 p-8">
                <?php if(session('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                        role="alert">
                        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                    </div>
                <?php endif; ?>

                <?php if(session('notification_status')): ?>
                    <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded relative mb-4"
                        role="alert">
                        <span class="block sm:inline">🔔 <?php echo e(session('notification_status')); ?></span>
                    </div>
                <?php endif; ?>

                <?php if(session('notification_error')): ?>
                    <div class="bg-orange-100 border border-orange-400 text-orange-700 px-4 py-3 rounded relative mb-4"
                        role="alert">
                        <span class="block sm:inline">⚠️ <?php echo e(session('notification_error')); ?></span>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                    </div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>

</html><?php /**PATH H:\WorkSpace\Antigravity\GoldCalculator\backend\resources\views/layouts/admin.blade.php ENDPATH**/ ?>