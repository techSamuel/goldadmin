<?php
require __DIR__ . '/vendor/autoload.php';

use App\Services\BajusScraperService;

// Mock Http Facade manually or just copy logic for testing
$html = file_get_contents('bajus.html');

echo "HTML Length: " . strlen($html) . "\n";

$pattern = '/<span class="price">([\d,]+)\s*BDT\/GRAM<\/span>/';
preg_match_all($pattern, $html, $matches);

print_r($matches);

if (empty($matches[1])) {
    echo "Pattern 1 failed. Trying pattern 2...\n";
    $pattern = '/class="price"\s*>([\d,]+)\s*BDT\/GRAM/';
    preg_match_all($pattern, $html, $matches);
    print_r($matches);
}
